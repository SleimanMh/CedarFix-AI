# v10.1 Bank-Aware Enhanced Pack

Created: 2026-05-20T16:04:38Z

## Purpose

This pack enhances v10 using the real `arabizi_candidate_bank.csv`.
It does **not** try to force duplicate candidate-bank rows. Instead it maps v10 rows to existing bank concepts, extracts variant deltas, splits non-candidate support assets, and isolates high-risk HITL terms.

## Key result

- Current candidate bank rows: 764
- v10 rows analyzed: 1281
- Candidate-target net-new rows: 0
- Existing candidate rows that can be enriched: 178
- High-risk HITL rows requiring second review: 113
- Variant patch candidates: 37

## Files

- `v10_1_bank_aware_enhanced.csv`: master v10.1 with bank mapping, disposition, matched candidate IDs, and variant deltas.
- `v10_1_candidate_bank_variant_patch_plan.csv`: rows where v10 can enrich existing bank variants after review.
- `v10_1_high_risk_hitl_second_review_queue.csv`: H-class rows that must not be absorbed automatically.
- `v10_1_general_word_bank_asset.csv`: general-language support rows outside candidate bank.
- `v10_1_protected_combos_asset.csv`: protected phrase rows; context-only.
- `v10_1_internet_notation_rules_asset.csv`: notation rules; no blind replacement.
- `v10_1_stoplist_support_asset.csv`: support/stoplist rows.
- `v10_1_candidate_bank_enriched_preview_do_not_auto_merge.csv`: original candidate bank plus v10.1 patch metadata; this is a preview only.
- `v10_1_summary.csv`: counts and disposition metrics.

## Rules

1. Do not create duplicate rows for concepts already in `arabizi_candidate_bank.csv`.
2. Do not auto-merge variant patches. Use the patch plan for review.
3. H-class rows require second reviewer and default to HITL/context signal only.
4. General words, notation rules, protected combos, and stoplist/support rows belong outside the candidate bank.
5. Routing, severity, and auto-promotion remain disabled.
