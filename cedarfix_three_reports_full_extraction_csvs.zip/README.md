# CedarFix three-report full extraction CSV package

Generated: 2026-05-30

Source reports:
1. `/mnt/data/deep-research-report (1).md` — combined Phase 1 + Phase 2 report.
2. `/mnt/data/deep-research-report (2).md` — official municipality/union complaint-channel report.
3. `/mnt/data/deep-research-report (3).md` — complaint-source universe report.

What was extracted:
- Every fenced CSV block into its own valid UTF-8-BOM CSV.
- Combined same-name CSV outputs where possible.
- Every markdown table into its own CSV.
- A long-form table of all markdown table cells.
- Full text of every markdown section.
- Ranked source lists.
- Manual-review / do-not-scrape source lists.
- Phase 2 summary counts and priority groups.
- Deduplicated URL index.
- Raw markdown copies for audit.

Important:
- This package extracts the uploaded reports; it does not perform new web research.
- Some report CSV blocks contained minor formatting issues. The extractor used a tolerant line-by-line parser so the output files are valid CSVs.
- `JOIN_REQUIRED` and `TBD:*` keys remain unresolved because the registry join file was not included in this task.
- The reports themselves warn not to promote Baldati/Baladi Map or blocked official endpoints beyond their evidence level.
