# CedarFix Lebanon Municipality Complaint Routing Research

## Executive summary

This pass focused on two deliverables: a **Phase 1 complaint-source universe** and a **Phase 2 extraction of official municipality and union complaint channels**. The highest-confidence result is that a small but important set of Lebanese municipality websites already exposes auditable complaint workflows in public: **Tripoli**, **Zahlé**, and **Ras El-Matn** each expose structured complaint or issue-reporting flows, while the **Al Fayhaa Union of Municipalities** exposes a union-level complaints form that explicitly covers **Tripoli, El-Beddawi, Mina, and Al-Qalamoun**. Several other municipalities clearly expose complaint or suggestions links but were blocked during machine access and therefore remain **official-but-manual-review** rather than fully verified, notably **Aley, Nabay, and El-Beddawi**. By contrast, some official domains are currently broken, compromised, or blocked, including **Jbail-Byblos** (default phpBB forum), **Jounieh** (502), **Bcharri** (503), and **Moukhtara** (bot verification). citeturn20view0turn21view4turn58view0turn20view3turn19view1turn21view3turn51view0turn51view1turn52view0turn24view0turn47view0turn47view1turn61view0

At the source-family level, the strongest evidence remains **official municipality / union sites** for workflow proof, **DGLAC** for official identity and registry support, and **national public-entity channels** such as **ISF**, **Ogero**, and the **South Lebanon Water Establishment** for complaint-routing fallbacks when an issue is not municipal. **Baladi Map** is useful and increasingly rich for public issue evidence, categories, and fix-status logic, but it explicitly says it does **not guarantee municipality response or resolution times**, so it should remain third-party evidence unless a municipality itself confirms adoption. **Baldati** remains a candidate platform in this pass because the site URL was reachable but did not render extractable text in the current session, so municipality-level participation could not be independently confirmed here. citeturn35view0turn35view2turn30view1turn76view0turn76view1turn76view3turn70view0turn72view0turn72view3

This synthesis follows the user-provided project brief and earlier round-report context supplied in the conversation. fileciteturn0file0 fileciteturn0file1

## Phased work timeline

```mermaid
timeline
    title CedarFix municipality complaint-routing phases
    2026-05-30 : Phase 1 source-universe audit
               : Official municipality / union / civic / national-agency source mapping
    2026-05-30 : Phase 2 official-channel extraction
               : Verified complaint forms, tracking pages, blocked official endpoints, union memberships
    Next : Manual browser review of anti-bot / 406 / 502 / 503 municipalities
    Next : Countrywide join against municipality registry and federation membership registry
    Next : Municipality-by-municipality expansion using verified official domains first
```

## Phase 1 findings

The complaint-source universe is already broad enough to support a disciplined routing strategy. **DGLAC** confirms the official registry structure, exposes municipality directory records, and even exposes a generic “Track Your Forms Status” widget, but it does **not** by itself prove that any given municipality accepts civic complaints online. Official municipality sites are the strongest evidence tier because they can prove the existence of a complaint form, required fields, attachments, categories, and sometimes tracking. Official union sites can also prove a valid workflow when the union explicitly accepts complaints and names its member municipalities. citeturn35view0turn35view2turn36view0turn21view3turn20view0turn19view1turn20view3

Among civic platforms, **Baladi Map** is the clearest reusable third-party source discovered in this pass. Its terms explicitly describe it as a platform for reporting genuine infrastructure problems, state that reports require admin approval, require location/photo/classification, and say fixed issues require proof of resolution from the municipality; it also says it does **not** guarantee municipal response or resolution times. Its live issues and scoreboard pages already expose municipality names, issue titles, dates, affected counts, and community-confirmed fix rates. That makes it valuable for **issue discovery, categorization, and public-status evidence**, but not for proving official municipal responsibility or SLAs. citeturn30view1turn76view0turn76view1turn76view3

National public entities are also highly relevant because many complaints that citizens perceive as “municipal” are operationally owned elsewhere. **ISF** exposes an anonymous complaints workflow with categories including “Construction Violation” and “Encroach upon public property,” plus optional callback and attachments. **Ogero** exposes contact details, app links, and customer-service entry points. The **South Lebanon Water Establishment** exposes hotline language, customer-service navigation, bill inquiry, and e-payment. These should be treated as **routing alternatives**, not municipality workflows. **NNA** is useful as the official government news agency and explicitly offers a mobile app plus WhatsApp breaking-news subscription, which makes it a useful official news-monitoring source for municipal incidents and announcements, but not as a municipality complaint form. citeturn85view0turn70view0turn72view0turn83view0turn83view1turn82search4

Several official municipal domains require manual review because the public evidence is strong enough to justify continued attention, but automation is unreliable. **Aley** exposes a complaint route in site navigation, yet the complaint page is protected by bot verification. **Nabay** and **El-Beddawi** expose official homepage links for “Send Complaints” and “Send Suggestions,” but the linked subpages returned `406 Not Acceptable` in this session. **Jbail-Byblos** currently resolves to a default phpBB forum page rather than a functioning municipal site. **Jounieh** returned `502 Bad Gateway`, **Bcharri** returned `503 Service Unavailable`, and **Moukhtara** shows robot verification at the root. Those are not reasons to discard them; they are reasons to mark them as **manual-review / blocked / broken official domains**. citeturn51view2turn52view0turn51view0turn53view0turn51view1turn53view2turn24view0turn47view0turn47view1turn61view0

### Source families and what they can and cannot prove

| source_family | what it can prove | what it cannot prove |
|---|---|---|
| official_municipality_site | official identity, official contact data, official complaint forms, official tracking pages, exact fields/categories when public | cross-municipality coverage beyond that municipality |
| municipal_union_site | official union-level complaint intake, union contact details, member municipalities when explicitly named | automatic applicability to all nearby municipalities unless membership is explicit |
| dglac | official registry identity, municipality existence, address/email/website fields, national directory coverage | that a municipality actually runs an online complaint workflow |
| civic_platform | public issue evidence, categories, public sentiment, fix-status logic when platform documents it | official municipal adoption, legal responsibility, guaranteed response times |
| candidate_platform | existence of a reusable platform or app family | municipality-level participation unless verified per municipality |
| national_agency | valid fallback channels for public-safety, telecom, water, or infrastructure owners | that a municipality itself is responsible for or receives that complaint |
| news | incident discovery, official statement monitoring, complaint-related reporting | official complaint intake, tracking, or department assignment |

### Phase 1 source universe

**Simulated file path:** `/exports/phase1/complaint_source_universe.csv`

The CSV below is intentionally conservative. Each row preserves the source URL and a short evidence snippet so it can be audited later. The rows are compiled from the cited official and platform pages. citeturn35view0turn35view2turn20view0turn19view1turn20view3turn21view3turn30view1turn76view1turn72view3turn70view0turn72view0turn83view0

```csv
source_id,source_name,source_url,source_family,coverage_scope,municipalities_covered_if_known,complaint_evidence_type,does_it_have_actual_complaints,does_it_have_complaint_form,does_it_have_status_tracking,does_it_have_hotline_or_whatsapp,does_it_have_resolution_evidence,evidence_snippet,reliability_level,automation_risk,terms_or_access_warning,recommended_use,priority_for_next_phase
SRC001,DGLAC Municipalities Directory,https://www.dglac.gov.lb/en/municipalities,dglac,national,"All municipalities listed by governorate/district",form,unknown,no,yes,no,no,"Municipality WEBSITE ... Track Your Forms Status",verified_official,low,"Federations path unreliable in this pass",Use for official identity/contact support; not for complaint-proof,high
SRC002,Tripoli Municipality official site,https://tripoli.gov.lb/,official_municipality_site,local,Tripoli,form,yes,yes,yes,no,no,"تقديم شكوى ... استعلام عن شكوى",verified_official,low,,Mine fully; strongest municipal workflow found,high
SRC003,Tripoli Municipality complaint form,https://tripoli.gov.lb/%D8%AA%D9%82%D8%AF%D9%8A%D9%85-%D8%B4%D9%83%D9%88%D9%89,official_municipality_site,local,Tripoli,form,yes,yes,yes,no,no,"نظافة-مجارير عامة-تعدي على الملك العام-ضجيج-دخان-مولدات",verified_official,low,,Primary complaint workflow source,high
SRC004,Tripoli Municipality complaint tracking,https://tripoli.gov.lb/chakwa,official_municipality_site,local,Tripoli,form,unknown,no,yes,no,no,"رقم الشكوى ... اختر السنة",verified_official,low,,Use for tracking capability evidence,high
SRC005,Tripoli Municipality objection form,https://tripoli.gov.lb/%D8%A7%D8%B9%D8%AA%D8%B1%D8%A7%D8%B6-%D8%B9%D9%84%D9%89-%D8%A7%D9%84%D8%A8%D9%84%D8%AF%D9%8A%D8%A9,official_municipality_site,local,Tripoli,form,yes,yes,yes,no,no,"أسباب الإعتراض ... اعتراض على قرار بلدي",verified_official,low,,Use as secondary grievance workflow,high
SRC006,Zahlé Municipality report-issue page,https://zahle.gov.lb/report-an-issue/,official_municipality_site,local,Zahlé,form,yes,yes,no,yes,no,"Call on our hotline 888 906 or fill the form below",verified_official,low,,Primary issue-report workflow source,high
SRC007,Ras El-Matn complaints page,https://raselmatn.gov.lb/Complaints,official_municipality_site,local,Ras El-Matn,form,yes,yes,no,no,no,"تقديم شكوى أو ملاحظة",verified_official,low,,Primary complaint workflow source,high
SRC008,Aley Municipality official site,https://aley.gov.lb/,official_municipality_site,local,Aley,form,unknown,unknown,no,no,no,"اتصل بنا ... الإقتراحات",likely_official,medium,"Complaint page blocked by verification wall",Manual review likely worthwhile,high
SRC009,Aley Municipality complaints page,https://aley.gov.lb/ar/complaints,official_municipality_site,local,Aley,form,unknown,unknown,unknown,no,no,"Please wait while your request is being verified",likely_official,high,"Manual browser review required",Confirm fields and whether complaint submissions still work,high
SRC010,Nabay Municipality official site,https://nabay.gov.lb/,official_municipality_site,local,Nabay,form,unknown,unknown,no,no,no,"إرسال الاقتراحات ... إرسال الشكاوى",verified_official,medium,"Complaint subpages returned 406/Cache miss",Use homepage as official proof and review subpages manually,high
SRC011,El-Beddawi Municipality official site,https://el-beddawi.gov.lb/,official_municipality_site,local,El-Beddawi,form,unknown,unknown,no,no,no,"إرسال الاقتراحات ... إرسال الشكاوى",verified_official,medium,"Complaint subpages returned 406/Cache miss",Use homepage as official proof and review subpages manually,high
SRC012,Nabatieh Municipality official site,https://nabatieh.gov.lb/,official_municipality_site,local,Nabatieh,form,unknown,no,no,no,no,"Phone: +961-7-760000 Email:info@nabatieh.gov.lb",verified_official,low,,Use for official contact only; no complaint flow found,medium
SRC013,Zouk Mikael Municipality official site,https://zoukmikael.gov.lb/,official_municipality_site,local,Zouk Mikael,app,unknown,no,no,no,no,"Our e-services ... Mobile App",verified_official,low,,Use for official contact/app evidence; complaint workflow not found,medium
SRC014,Jbail-Byblos Municipality domain,https://jbail-byblos.gov.lb/,official_municipality_site,local,Jbail/Byblos,archive,unknown,no,no,no,no,"My forum ... Powered by phpBB",candidate_unverified,high,"Domain appears compromised/nonfunctional",Manual review only; do not trust content,high
SRC015,Jounieh Municipality domain,https://www.jounieh.gov.lb/,official_municipality_site,local,Jounieh,archive,unknown,no,no,no,no,"502 Bad Gateway",candidate_unverified,high,"Site unavailable in this pass",Manual review only,high
SRC016,Bcharri Municipality domain,https://www.bcharri.gov.lb/,official_municipality_site,local,Bcharri,archive,unknown,no,no,no,no,"503 Service Unavailable",candidate_unverified,high,"Site unavailable in this pass",Manual review only,high
SRC017,Moukhtara Municipality domain,https://moukhtara.gov.lb/,official_municipality_site,local,Moukhtara,archive,unknown,no,no,no,no,"Verifying that you are not a robot",likely_official,high,"Bot-protected",Manual browser review required,high
SRC018,Al Fayhaa Union complaint form,https://urbcomfayhaa.gov.lb/en/send-complaints/,municipal_union_site,regional,"Union, Mina, Al-Qalamoun, Tripoli, El-Beddawi",form,unknown,yes,no,no,no,"Municipality Union Mina Al-Qalamoun Tripoli El-Beddawi",verified_official,low,,Best verified union fallback discovered,high
SRC019,Baladi Map terms,https://www.baladimap.com/en/terms,civic_platform,national,"Multiple municipalities visible on issues/scoreboard",public_issues,yes,yes,no,no,yes,"We do not guarantee municipality response or resolution times",civic_platform,low,"Platform login required for report flow",Use for lead generation and public issue evidence only,high
SRC020,Baladi Map issues,https://www.baladimap.com/en/issues,civic_platform,national,"Dekwaneh, Beirut, Bassaba visible in indexed issues",public_issues,yes,yes,no,no,yes,"Browse infrastructure issues reported across Lebanon",civic_platform,low,,Mine for issue examples and categories,high
SRC021,Baldati,https://baldati.app/,candidate_platform,national,unknown,app,unknown,unknown,unknown,unknown,unknown,"URL reachable but no parseable text in this session",candidate_unverified,medium,"JS/manual review needed",Treat as candidate platform only until municipality participation is verified,medium
SRC022,Ogero official site,https://ogero.gov.lb/,national_agency,national,All Lebanon,app,unknown,no,no,no,no,"1515 ... Contact us ... Download Ogero's Application",verified_official,low,,Use as telecom fallback route,medium
SRC023,South Lebanon Water Establishment,https://slwe.gov.lb/,national_agency,regional,South Lebanon,hotline,unknown,no,no,yes,no,"الخط الساخن ... استفسار عن فاتورة ... الدفع الالكتروني",verified_official,low,,Use as water-service fallback route in South,medium
SRC024,Internal Security Forces complaints,https://isf.gov.lb/anonymous-complaints/,national_agency,national,All Lebanon,form,unknown,yes,no,yes,no,"Construction Violation ... Encroach upon public property",verified_official,low,,Use for non-municipal legal/safety escalations,high
SRC025,National News Agency,https://www.nna-leb.gov.lb/en/,news,national,All Lebanon,whatsapp,unknown,no,no,yes,no,"Subscribe now to breaking news via WhatsApp",verified_official,low,,Use for official incident/news monitoring,medium
```

### Ranked top sources to mine next

1. Tripoli complaint form  
2. Tripoli complaint tracking  
3. Tripoli objection form  
4. Zahlé report-an-issue page  
5. Ras El-Matn complaints page  
6. Al Fayhaa Union complaints page  
7. Nabay homepage complaint/suggestions links  
8. El-Beddawi homepage complaint/suggestions links  
9. Aley complaints page behind verification  
10. DGLAC municipalities directory  
11. Baladi Map issues page  
12. Baladi Map scoreboard  
13. Nabatieh official site  
14. Zouk Mikael official site and app/e-services  
15. Ogero contact/app  
16. ISF anonymous complaints  
17. South Lebanon Water Establishment hotline/bill inquiry  
18. NNA app + WhatsApp feed  
19. Jbail-Byblos domain manual review  
20. Jounieh domain manual review  
21. Bcharri domain manual review  
22. Moukhtara domain manual review  
23. DGLAC municipal-federations path manual review  
24. Zahle linked Facebook page  
25. Zahle linked Instagram page  
26. Nabay linked Facebook page  
27. El-Beddawi linked Facebook page  
28. Zouk Mikael linked Facebook page  
29. Al Fayhaa linked Facebook page  
30. Baldati manual-review pass

### Sources that should not be scraped aggressively or should be manually reviewed

Use manual or low-rate checks only for the following:

- `https://aley.gov.lb/ar/complaints` — verification wall. citeturn52view0
- `https://nabay.gov.lb/send-complaint-ar/` and `https://nabay.gov.lb/send-suggestions-ar/` — 406 / cache issues from official link targets. citeturn53view0turn53view1
- `https://el-beddawi.gov.lb/send-complaint-ar/` and `https://el-beddawi.gov.lb/send-suggestions-ar/` — 406 / cache issues from official link targets. citeturn53view2turn53view3
- `https://moukhtara.gov.lb/` — bot verification. citeturn61view0
- `https://jbail-byblos.gov.lb/` — currently serves a default forum, suggesting compromise or breakdown. citeturn24view0turn24view1
- `https://www.jounieh.gov.lb/` — 502. citeturn47view0
- `https://www.bcharri.gov.lb/` — 503. citeturn47view1
- Facebook page URLs discovered from official sites — machine access is heavily rate-limited / blocked. citeturn74view1turn74view2turn75view2
- `https://baldati.app/` — JS/manual review required in this session. citeturn30view0

## Phase 2 findings

The strongest verified municipal workflows are concentrated in a few municipalities. **Tripoli** is the most mature by a wide margin: it exposes a public complaint form for general public-interest issues, a separate municipal objection form with enumerated reasons, and a complaint-tracking page by complaint number and year. **Zahlé** exposes a report-an-issue page with a hotline (`888 906`) plus a form that accepts complaint/comment/claim types and an attachment. **Ras El-Matn** exposes a complaint-or-note page with a simple but public form. **Al Fayhaa Union** provides a region-level complaint form where the submitter can choose the target municipality. citeturn20view0turn21view4turn58view0turn19view1turn20view3turn21view3

The next tier is **official-but-not-fully-machine-verifiable**. **Aley** clearly has a complaint route in site navigation and a reachable complaint URL, but the form is behind verification. **Nabay** and **El-Beddawi** clearly expose “Send Complaints” and “Send Suggestions” links on their official homepages, yet their subpages failed in this pass. These should be treated as **real official leads** with `blocked_needs_manual_review`, not discarded. **Nabatieh** and **Zouk Mikael** are useful official contact sources, but in this pass I did **not** find a public complaint workflow on those sites. Zouk Mikael does, however, expose e-services and a municipal mobile-app surface, which could merit a later authenticated/manual review. citeturn51view2turn52view0turn51view0turn53view0turn51view1turn53view2turn61view2turn26view2turn27view1

Several priority municipalities remain unresolved because their official digital surfaces are unavailable or unsafe to trust in the current state. **Jbail-Byblos** cannot currently be treated as a valid official workflow source because the domain serves a default “My forum” page. **Jounieh**, **Bcharri**, and **Moukhtara** each need manual verification before any routing logic should rely on them. This means the project should separate “no evidence found” from “official domain exists but is technically unusable right now,” because those are operationally different states. citeturn24view0turn47view0turn47view1turn61view0

### Phase 2 summary counts

- **Verified complaint workflows found:** 6  
  - Tripoli complaint form  
  - Tripoli objection form  
  - Tripoli complaint tracking  
  - Zahlé report-an-issue  
  - Ras El-Matn complaint/observation  
  - Al Fayhaa Union complaint form  
- **Blocked but clearly present official complaint endpoints:** 5  
  - Aley complaints  
  - Nabay complaints  
  - Nabay suggestions  
  - El-Beddawi complaints  
  - El-Beddawi suggestions  
- **Official contact-only municipality sites found:** 3  
  - Nabatieh  
  - Zouk Mikael  
  - Aley contact page  
- **Union fallback channels found:** 1 union covering 4 named municipalities  
- **Broken / nonfunctional official domains needing manual review:** 4  
  - Jbail-Byblos  
  - Jounieh  
  - Bcharri  
  - Moukhtara  

## Phase 2 outputs

### municipality_official_channels.csv

**Simulated file path:** `/exports/phase2/municipality_official_channels.csv`

The file below uses `JOIN_REQUIRED` for municipality IDs because no registry join table was provided in this turn. Where a complaint page or contact page was blocked, I kept the official URL and marked the status conservatively. The rows are compiled from the official and union pages cited above. citeturn20view0turn21view4turn58view0turn19view1turn20view3turn51view2turn52view1turn51view0turn51view1turn61view2turn26view2turn27view1

```csv
channel_id,municipality_id_if_known,municipality_name_ar,municipality_name_en,governorate,district,entity_level,entity_name,channel_type,channel_url,phone,whatsapp,email,address,complaint_form_url,complaint_tracking_url,app_url,accepted_complaint_categories,required_fields,has_photo_upload,has_location_field,has_tracking,mentions_department_assignment,mentions_response_deadline,response_deadline_text,emergency_warning_present,source_url,evidence_snippet,verification_status,confidence,last_checked,notes
CH001,JOIN_REQUIRED,بلدية طرابلس,Tripoli,North,Tripoli,municipality,Tripoli Municipality,official_website,https://tripoli.gov.lb/,,,,,,https://tripoli.gov.lb/%D8%AA%D9%82%D8%AF%D9%8A%D9%85-%D8%B4%D9%83%D9%88%D9%89,https://tripoli.gov.lb/chakwa,,"General civic complaints; see complaint row",,unknown,unknown,yes,no,no,,no,https://tripoli.gov.lb/,"تقديم شكوى ... استعلام عن شكوى",verified_official,98,2026-05-30,"Public complaint + tracking surfaced from official navigation"
CH002,JOIN_REQUIRED,بلدية طرابلس,Tripoli,North,Tripoli,municipality,Tripoli Municipality,complaint_form,https://tripoli.gov.lb/%D8%AA%D9%82%D8%AF%D9%8A%D9%85-%D8%B4%D9%83%D9%88%D9%89,,,,,,"https://tripoli.gov.lb/%D8%AA%D9%82%D8%AF%D9%8A%D9%85-%D8%B4%D9%83%D9%88%D9%89",https://tripoli.gov.lb/chakwa,,"نظافة; مجارير عامة; تعدي على الملك العام; ضجيج; دخان; مولدات","الاسم; البريد الالكتروني; رقم الهاتف; عنوان; نص الشكوى",yes,unknown,yes,no,no,,no,https://tripoli.gov.lb/%D8%AA%D9%82%D8%AF%D9%8A%D9%85-%D8%B4%D9%83%D9%88%D9%89,"هذه الصفحة مخصصة لتقديم الشكاوي ذات الطابع العام",verified_official,99,2026-05-30,"Explicit exclusion of private complaints"
CH003,JOIN_REQUIRED,بلدية طرابلس,Tripoli,North,Tripoli,municipality,Tripoli Municipality,complaint_tracking,https://tripoli.gov.lb/chakwa,,,,,,https://tripoli.gov.lb/%D8%AA%D9%82%D8%AF%D9%8A%D9%85-%D8%B4%D9%83%D9%88%D9%89,https://tripoli.gov.lb/chakwa,,, "رقم الشكوى; السنة",no,no,yes,no,no,,no,https://tripoli.gov.lb/chakwa,"رقم الشكوى ... اختر السنة",verified_official,97,2026-05-30,"Tracking exists on official site"
CH004,JOIN_REQUIRED,بلدية طرابلس,Tripoli,North,Tripoli,municipality,Tripoli Municipality,complaint_form,https://tripoli.gov.lb/%D8%A7%D8%B9%D8%AA%D8%B1%D8%A7%D8%B6-%D8%B9%D9%84%D9%89-%D8%A7%D9%84%D8%A8%D9%84%D8%AF%D9%8A%D8%A9,,,,,,"https://tripoli.gov.lb/%D8%A7%D8%B9%D8%AA%D8%B1%D8%A7%D8%B6-%D8%B9%D9%84%D9%89-%D8%A7%D9%84%D8%A8%D9%84%D8%AF%D9%8A%D8%A9",https://tripoli.gov.lb/chakwa,,"اعتراض على عمل البلدية; اعتراض على معاملة إدارية; اعتراض على تصرف أحد الموظفين; اعتراض على قرار بلدي","الاسم; البريد الالكتروني; العنوان; رقم الهاتف; أسباب الاعتراض; نص الاعتراض",yes,unknown,yes,no,no,,no,https://tripoli.gov.lb/%D8%A7%D8%B9%D8%AA%D8%B1%D8%A7%D8%B6-%D8%B9%D9%84%D9%89-%D8%A7%D9%84%D8%A8%D9%84%D8%AF%D9%8A%D8%A9,"أسباب الإعتراض ... اعتراض على قرار بلدي",verified_official,98,2026-05-30,"Separate grievance/objection workflow"
CH005,JOIN_REQUIRED,بلدية زحلة,Zahlé,Bekaa,Zahlé,municipality,Zahlé Municipality,official_website,https://zahle.gov.lb/,888906,,,,https://zahle.gov.lb/report-an-issue/,,, "Complaints; comments; claims",,unknown,unknown,no,no,no,,no,https://zahle.gov.lb/,"Hotline 888 906",verified_official,95,2026-05-30,"Hotline surfaced on official site"
CH006,JOIN_REQUIRED,بلدية زحلة,Zahlé,Bekaa,Zahlé,municipality,Zahlé Municipality,hotline,https://zahle.gov.lb/report-an-issue/,888906,,,,https://zahle.gov.lb/report-an-issue/,,,,,no,no,no,no,no,,no,https://zahle.gov.lb/report-an-issue/,"Call on our hotline 888 906",verified_official,96,2026-05-30,"Public hotline is part of issue workflow"
CH007,JOIN_REQUIRED,بلدية زحلة,Zahlé,Bekaa,Zahlé,municipality,Zahlé Municipality,complaint_form,https://zahle.gov.lb/report-an-issue/,888906,,,,https://zahle.gov.lb/report-an-issue/,,, "Complaint; comment; claim","Name; phone; email optional; type; municipality issue",yes,unknown,no,no,no,,no,https://zahle.gov.lb/report-an-issue/,"If you have a complaint, a comment or a problem",verified_official,98,2026-05-30,"Attachment upload visible; tracking not found"
CH008,JOIN_REQUIRED,بلدية رأس المتن,Ras El-Matn,Mount Lebanon,Baabda,municipality,Ras El-Matn Municipality,official_website,https://raselmatn.gov.lb/,+96100961380357,,info@raselmatn.gov.lb,"Ras El-Matn, Baabda, Lebanon",https://raselmatn.gov.lb/Complaints,,, "شكوى; ملاحظة",,unknown,unknown,no,no,no,,no,https://raselmatn.gov.lb/Complaints,"تقديم شكوى أو ملاحظة",verified_official,96,2026-05-30,"Contact info appears on complaint page footer"
CH009,JOIN_REQUIRED,بلدية رأس المتن,Ras El-Matn,Mount Lebanon,Baabda,municipality,Ras El-Matn Municipality,complaint_form,https://raselmatn.gov.lb/Complaints,+96100961380357,,info@raselmatn.gov.lb,"Ras El-Matn, Baabda, Lebanon",https://raselmatn.gov.lb/Complaints,,, "شكوى; ملاحظة","الاسم اختياري; البريد الإلكتروني اختياري; نوع الطلب; الرسالة",no,no,no,no,no,,no,https://raselmatn.gov.lb/Complaints,"نوع الطلب: شكوى / ملاحظة",verified_official,99,2026-05-30,"Simple public complaint/observation form"
CH010,JOIN_REQUIRED,بلدية عاليه,Aley,Mount Lebanon,Aley,municipality,Municipality of Aley,official_website,https://aley.gov.lb/,05/554305 | 05/554001/2 | 05/557112,,info@aley.gov.lb,,https://aley.gov.lb/ar/complaints,,, "Complaints likely; suggestions visible in nav",,unknown,unknown,unknown,no,no,,no,https://aley.gov.lb/,"اتصل بنا ... الإقتراحات",likely_official,88,2026-05-30,"Official site confirmed"
CH011,JOIN_REQUIRED,بلدية عاليه,Aley,Mount Lebanon,Aley,municipality,Municipality of Aley,official_contact_page,https://aley.gov.lb/ar/contact,"05/554305 | 05/554001/2 | 05/557112",,info@aley.gov.lb,,https://aley.gov.lb/ar/complaints,,,,"Form on contact page not parsed",unknown,unknown,no,no,no,,no,https://aley.gov.lb/ar/contact,"بلدية عاليه ... info@aley.gov.lb",verified_official,92,2026-05-30,"Contact page reached successfully"
CH012,JOIN_REQUIRED,بلدية عاليه,Aley,Mount Lebanon,Aley,municipality,Municipality of Aley,complaint_form,https://aley.gov.lb/ar/complaints,"05/554305 | 05/554001/2 | 05/557112",,info@aley.gov.lb,,https://aley.gov.lb/ar/complaints,,,,,unknown,unknown,unknown,no,no,,no,https://aley.gov.lb/ar/complaints,"Please wait while your request is being verified",blocked_needs_manual_review,76,2026-05-30,"Official complaint endpoint exists but is bot-protected"
CH013,JOIN_REQUIRED,بلدية نابيه,Nabay,Mount Lebanon,Matn,municipality,Nabay Municipality,official_website,https://nabay.gov.lb/,+9614808881,,info@nabay.gov.lb,"Lebanon, Nabay - Municipality Building",https://nabay.gov.lb/send-complaint-ar/,,, "Complaints and suggestions links exposed",,unknown,unknown,unknown,no,no,,no,https://nabay.gov.lb/,"إرسال الاقتراحات ... إرسال الشكاوى",verified_official,93,2026-05-30,"Homepage exposes complaint/suggestions links"
CH014,JOIN_REQUIRED,بلدية نابيه,Nabay,Mount Lebanon,Matn,municipality,Nabay Municipality,complaint_form,https://nabay.gov.lb/send-complaint-ar/,+9614808881,,info@nabay.gov.lb,"Lebanon, Nabay - Municipality Building",https://nabay.gov.lb/send-complaint-ar/,,,,,unknown,unknown,unknown,no,no,,no,https://nabay.gov.lb/,"Homepage link text: إرسال الشكاوى",blocked_needs_manual_review,78,2026-05-30,"Linked from official site; target returned 406"
CH015,JOIN_REQUIRED,بلدية نابيه,Nabay,Mount Lebanon,Matn,municipality,Nabay Municipality,suggestion_form,https://nabay.gov.lb/send-suggestions-ar/,+9614808881,,info@nabay.gov.lb,"Lebanon, Nabay - Municipality Building",,,"","Suggestions","unknown",unknown,unknown,no,no,no,,no,https://nabay.gov.lb/,"Homepage link text: إرسال الاقتراحات",blocked_needs_manual_review,74,2026-05-30,"Linked from official site; target not fetched"
CH016,JOIN_REQUIRED,بلدية البداوي,El-Beddawi,North,Tripoli,municipality,El-Beddawi Municipality,official_website,https://el-beddawi.gov.lb/,+9616389977,,info@el-beddawi.gov.lb,"Lebanon, El-Beddawi - Municipality Building",https://el-beddawi.gov.lb/send-complaint-ar/,,, "Complaints and suggestions links exposed",,unknown,unknown,unknown,no,no,,no,https://el-beddawi.gov.lb/,"إرسال الاقتراحات ... إرسال الشكاوى",verified_official,93,2026-05-30,"Homepage exposes complaint/suggestions links"
CH017,JOIN_REQUIRED,بلدية البداوي,El-Beddawi,North,Tripoli,municipality,El-Beddawi Municipality,complaint_form,https://el-beddawi.gov.lb/send-complaint-ar/,+9616389977,,info@el-beddawi.gov.lb,"Lebanon, El-Beddawi - Municipality Building",https://el-beddawi.gov.lb/send-complaint-ar/,,,,,unknown,unknown,unknown,no,no,,no,https://el-beddawi.gov.lb/,"Homepage link text: إرسال الشكاوى",blocked_needs_manual_review,78,2026-05-30,"Linked from official site; target returned 406"
CH018,JOIN_REQUIRED,بلدية البداوي,El-Beddawi,North,Tripoli,municipality,El-Beddawi Municipality,suggestion_form,https://el-beddawi.gov.lb/send-suggestions-ar/,+9616389977,,info@el-beddawi.gov.lb,"Lebanon, El-Beddawi - Municipality Building",,,"","Suggestions","unknown",unknown,unknown,no,no,no,,no,https://el-beddawi.gov.lb/,"Homepage link text: إرسال الاقتراحات",blocked_needs_manual_review,74,2026-05-30,"Linked from official site; target not fetched"
CH019,JOIN_REQUIRED,بلدية مدينة النبطية,Nabatieh,Nabatiyeh,Nabatiyeh,municipality,Nabatieh Municipality,official_website,https://nabatieh.gov.lb/,+961-7-760000,,info@nabatieh.gov.lb,, ,,, , ,unknown,unknown,no,no,no,,no,https://nabatieh.gov.lb/,"بلدية مدينة النبطية ... Phone: +961-7-760000",verified_official,94,2026-05-30,"Official site works; complaint page not found"
CH020,JOIN_REQUIRED,بلدية مدينة النبطية,Nabatieh,Nabatiyeh,Nabatiyeh,municipality,Nabatieh Municipality,generic_contact_only,https://nabatieh.gov.lb/,+961-7-760000,,info@nabatieh.gov.lb,, ,,, , ,unknown,unknown,no,no,no,,no,https://nabatieh.gov.lb/,"### اتصل بنا",verified_official,90,2026-05-30,"Use for generic contact only"
CH021,JOIN_REQUIRED,بلدية ذوق مكايل,Zouk Mikael,Mount Lebanon,Keserwan,municipality,Zouk Mikael Municipality,official_website,https://zoukmikael.gov.lb/,"+961-9-212212 | +961-9-212217",,info@zoukmikael.gov.lb,"Zouk Mikael - Main Road",,,https://zoukmikaelmunicipality.microsoftcrmportals.com/CitizenSignIn,,"",unknown,unknown,no,no,no,,no,https://zoukmikael.gov.lb/,"Our e-services ... Mobile App",verified_official,92,2026-05-30,"Payments/app surface visible; no public complaint flow found"
CH022,JOIN_REQUIRED,بلدية ذوق مكايل,Zouk Mikael,Mount Lebanon,Keserwan,municipality,Zouk Mikael Municipality,official_contact_page,https://zoukmikael.gov.lb/contact-us/,"+961-9-212212 | +961-9-212217",,info@zoukmikael.gov.lb,"Zouk Mikael - Main Road",,,https://zoukmikaelmunicipality.microsoftcrmportals.com/CitizenSignIn,,"",unknown,unknown,no,no,no,,no,https://zoukmikael.gov.lb/contact-us/,"info@zoukmikael.gov.lb",verified_official,91,2026-05-30,"Contact page is generic"
CH023,JOIN_REQUIRED,بلدية ذوق مكايل,Zouk Mikael,Mount Lebanon,Keserwan,municipality,Zouk Mikael Municipality,app,https://zoukmikael.gov.lb/,"+961-9-212212 | +961-9-212217",,info@zoukmikael.gov.lb,"Zouk Mikael - Main Road",,,https://zoukmikaelmunicipality.microsoftcrmportals.com/CitizenSignIn,,"",unknown,unknown,no,no,no,,no,https://zoukmikael.gov.lb/,"Zouk Mikael Municipality Mobile App",verified_official,88,2026-05-30,"App purpose shown as fee payment, not complaints"
```

### municipality_complaint_workflows.csv

**Simulated file path:** `/exports/phase2/municipality_complaint_workflows.csv`

```csv
workflow_id,municipality_id_if_known,municipality_name_ar,municipality_name_en,governorate,district,entity_level,entity_name,complaint_form_url,complaint_tracking_url,accepted_complaint_categories,required_fields,has_photo_upload,has_location_field,has_tracking,mentions_department_assignment,mentions_response_deadline,response_deadline_text,emergency_warning_present,source_url,evidence_snippet,verification_status,confidence,last_checked,notes
WF001,JOIN_REQUIRED,بلدية طرابلس,Tripoli,North,Tripoli,municipality,Tripoli Municipality,https://tripoli.gov.lb/%D8%AA%D9%82%D8%AF%D9%8A%D9%85-%D8%B4%D9%83%D9%88%D9%89,https://tripoli.gov.lb/chakwa,"General civic complaints: cleanliness; public sewers; encroachment on public property; noise; smoke; generators","Name; email; phone; address; complaint text",yes,unknown,yes,no,no,,no,https://tripoli.gov.lb/%D8%AA%D9%82%D8%AF%D9%8A%D9%85-%D8%B4%D9%83%D9%88%D9%89,"هذه الصفحة مخصصة لتقديم الشكاوي ذات الطابع العام",verified_official,99,2026-05-30,"Explicitly excludes private complaints"
WF002,JOIN_REQUIRED,بلدية طرابلس,Tripoli,North,Tripoli,municipality,Tripoli Municipality,https://tripoli.gov.lb/%D8%A7%D8%B9%D8%AA%D8%B1%D8%A7%D8%B6-%D8%B9%D9%84%D9%89-%D8%A7%D9%84%D8%A8%D9%84%D8%AF%D9%8A%D8%A9,https://tripoli.gov.lb/chakwa,"Objection to municipal action; administrative transaction; employee behavior; municipal decision","Name; email; address; phone; reason; objection text",yes,unknown,yes,no,no,,no,https://tripoli.gov.lb/%D8%A7%D8%B9%D8%AA%D8%B1%D8%A7%D8%B6-%D8%B9%D9%84%D9%89-%D8%A7%D9%84%D8%A8%D9%84%D8%AF%D9%8A%D8%A9,"اعتراض على عمل البلدية ... اعتراض على قرار بلدي",verified_official,98,2026-05-30,"Separate grievance workflow"
WF003,JOIN_REQUIRED,بلدية طرابلس,Tripoli,North,Tripoli,municipality,Tripoli Municipality,,https://tripoli.gov.lb/chakwa,"Tracking only","Complaint number; year",no,no,yes,no,no,,no,https://tripoli.gov.lb/chakwa,"رقم الشكوى ... اختر السنة",verified_official,97,2026-05-30,"Tracks prior submissions"
WF004,JOIN_REQUIRED,بلدية زحلة,Zahlé,Bekaa,Zahlé,municipality,Zahlé Municipality,https://zahle.gov.lb/report-an-issue/,"","Complaint; comment; claim","Name; phone; optional email; type; municipality issue",yes,unknown,no,no,no,,no,https://zahle.gov.lb/report-an-issue/,"Call on our hotline 888 906 or fill the form below",verified_official,98,2026-05-30,"Hotline + public form"
WF005,JOIN_REQUIRED,بلدية رأس المتن,Ras El-Matn,Mount Lebanon,Baabda,municipality,Ras El-Matn Municipality,https://raselmatn.gov.lb/Complaints,,"Complaint; note","Optional name; optional email; request type; message",no,no,no,no,no,,no,https://raselmatn.gov.lb/Complaints,"تقديم شكوى أو ملاحظة",verified_official,99,2026-05-30,"Very clean public workflow"
WF006,JOIN_REQUIRED,بلدية عاليه,Aley,Mount Lebanon,Aley,municipality,Municipality of Aley,https://aley.gov.lb/ar/complaints,,"Unknown; complaint route exists",unknown,unknown,unknown,unknown,no,no,,no,https://aley.gov.lb/ar/complaints,"Please wait while your request is being verified",blocked_needs_manual_review,76,2026-05-30,"Official route exists but content blocked"
WF007,JOIN_REQUIRED,بلدية نابيه,Nabay,Mount Lebanon,Matn,municipality,Nabay Municipality,https://nabay.gov.lb/send-complaint-ar/,,"Complaints link exists on official homepage",unknown,unknown,unknown,unknown,no,no,,no,https://nabay.gov.lb/,"إرسال الشكاوى",blocked_needs_manual_review,78,2026-05-30,"Homepage proves route exists; target failed"
WF008,JOIN_REQUIRED,بلدية نابيه,Nabay,Mount Lebanon,Matn,municipality,Nabay Municipality,https://nabay.gov.lb/send-suggestions-ar/,,"Suggestions link exists on official homepage",unknown,unknown,unknown,unknown,no,no,,no,https://nabay.gov.lb/,"إرسال الاقتراحات",blocked_needs_manual_review,74,2026-05-30,"Suggestion flow not fetched"
WF009,JOIN_REQUIRED,بلدية البداوي,El-Beddawi,North,Tripoli,municipality,El-Beddawi Municipality,https://el-beddawi.gov.lb/send-complaint-ar/,,"Complaints link exists on official homepage",unknown,unknown,unknown,unknown,no,no,,no,https://el-beddawi.gov.lb/,"إرسال الشكاوى",blocked_needs_manual_review,78,2026-05-30,"Homepage proves route exists; target failed"
WF010,JOIN_REQUIRED,بلدية البداوي,El-Beddawi,North,Tripoli,municipality,El-Beddawi Municipality,https://el-beddawi.gov.lb/send-suggestions-ar/,,"Suggestions link exists on official homepage",unknown,unknown,unknown,unknown,no,no,,no,https://el-beddawi.gov.lb/,"إرسال الاقتراحات",blocked_needs_manual_review,74,2026-05-30,"Suggestion flow not fetched"
WF011,JOIN_REQUIRED,اتحاد بلديات الفيحاء,Al Fayhaa Union,North,Tripoli,municipal_union,Al Fayhaa Union of Municipalities,https://urbcomfayhaa.gov.lb/en/send-complaints/,, "Union; Mina; Al-Qalamoun; Tripoli; El-Beddawi","First name; last name; phone; email; municipality selector; complaint",no,no,no,no,no,,no,https://urbcomfayhaa.gov.lb/en/send-complaints/,"Please fill the following form and our team will review your request",verified_official,96,2026-05-30,"Union-level fallback; no public tracking found"
```

### municipal_union_complaint_channels.csv

**Simulated file path:** `/exports/phase2/municipal_union_complaint_channels.csv`

```csv
channel_id,union_name,entity_level,channel_type,channel_url,phone,email,address,member_municipalities_if_explicit,source_url,evidence_snippet,verification_status,confidence,last_checked,notes
UC001,Al Fayhaa Union of Municipalities,municipal_union,official_website,https://urbcomfayhaa.gov.lb/en/send-complaints/,+9616424365,info@urbcomfayhaa.gov.lb,"Lebanon, Tripoli - Municipality Building","El-Beddawi; Tripoli; Mina; Qalamoun",https://urbcomfayhaa.gov.lb/en/send-complaints/,"The Union of Al-Fayhaa Municipalities ... Contact Us",verified_official,95,2026-05-30,"Official union site names municipalities"
UC002,Al Fayhaa Union of Municipalities,municipal_union,union_complaint_form,https://urbcomfayhaa.gov.lb/en/send-complaints/,+9616424365,info@urbcomfayhaa.gov.lb,"Lebanon, Tripoli - Municipality Building","Union; Mina; Al-Qalamoun; Tripoli; El-Beddawi",https://urbcomfayhaa.gov.lb/en/send-complaints/,"Municipality Union Mina Al-Qalamoun Tripoli El-Beddawi",verified_official,96,2026-05-30,"Best verified regional fallback"
```

### municipal_union_memberships.csv

**Simulated file path:** `/exports/phase2/municipal_union_memberships.csv`

```csv
membership_id,union_name,municipality_id_if_known,member_municipality_name_ar,member_municipality_name_en,governorate,district,source_url,evidence_snippet,verification_status,confidence,last_checked,notes
UM001,Al Fayhaa Union of Municipalities,JOIN_REQUIRED,بلدية طرابلس,Tripoli,North,Tripoli,https://urbcomfayhaa.gov.lb/en/send-complaints/,"Municipality ... Tripoli",verified_official,96,2026-05-30,"Named in form selector and site menu"
UM002,Al Fayhaa Union of Municipalities,JOIN_REQUIRED,بلدية البداوي,El-Beddawi,North,Tripoli,https://urbcomfayhaa.gov.lb/en/send-complaints/,"Municipality ... El-Beddawi",verified_official,96,2026-05-30,"Named in form selector and site menu"
UM003,Al Fayhaa Union of Municipalities,JOIN_REQUIRED,بلدية الميناء,Mina,North,Tripoli,https://urbcomfayhaa.gov.lb/en/send-complaints/,"Municipality ... Mina",verified_official,95,2026-05-30,"Named in form selector and site menu"
UM004,Al Fayhaa Union of Municipalities,JOIN_REQUIRED,بلدية القلمون,Al-Qalamoun,North,Tripoli,https://urbcomfayhaa.gov.lb/en/send-complaints/,"Municipality ... Al-Qalamoun",verified_official,95,2026-05-30,"Named in form selector and site menu"
```

### official_channel_backlog.csv

**Simulated file path:** `/exports/phase2/official_channel_backlog.csv`

```csv
task_id,municipality_id_if_known,municipality_name_ar,municipality_name_en,governorate,district,target_url_or_query,reason,status,priority,last_checked,notes
BK001,JOIN_REQUIRED,بلدية بيروت,Beirut,Beirut,Beirut,"official Beirut municipality complaint/contact workflow","No verified official complaint channel found in this pass",open,high,2026-05-30,"Search official domain + governor/municipality surfaces"
BK002,JOIN_REQUIRED,بلدية صيدا,Saida,South,Saida,"official Saida municipality complaint workflow","No verified official complaint channel found in this pass",open,high,2026-05-30,"Search municipality site + local official pages"
BK003,JOIN_REQUIRED,بلدية صور,Tyre,South,Tyre,"official Tyre municipality / union complaint workflow","No verified official complaint channel found in this pass",open,high,2026-05-30,"Search municipality site + Tyre union"
BK004,JOIN_REQUIRED,بلدية بعلبك,Baalbek,Baalbek-Hermel,Baalbek,"official Baalbek municipality complaint workflow","No verified official complaint channel found in this pass",open,high,2026-05-30,"High-priority city"
BK005,JOIN_REQUIRED,بلدية جبيل,Byblos,Mount Lebanon,Byblos,https://jbail-byblos.gov.lb/,"Official domain currently serves default forum",manual_review,high,2026-05-30,"Do not trust current content"
BK006,JOIN_REQUIRED,بلدية جونيه,Jounieh,Mount Lebanon,Keserwan,https://www.jounieh.gov.lb/,"Official domain returned 502",manual_review,high,2026-05-30,"Retry manually / confirm alternate official channel"
BK007,JOIN_REQUIRED,بلدية بشري,Bcharri,North,Bcharre,https://www.bcharri.gov.lb/,"Official domain returned 503",manual_review,high,2026-05-30,"Retry manually / confirm alternate official channel"
BK008,JOIN_REQUIRED,بلدية المختارة,Moukhtara,Mount Lebanon,Chouf,https://moukhtara.gov.lb/,"Bot verification at root",manual_review,high,2026-05-30,"Manual browser needed"
BK009,JOIN_REQUIRED,بلدية عاليه,Aley,Mount Lebanon,Aley,https://aley.gov.lb/ar/complaints,"Official complaint page is bot-protected",manual_review,high,2026-05-30,"Need fields screenshot and live-submit validation"
BK010,JOIN_REQUIRED,بلدية نابيه,Nabay,Mount Lebanon,Matn,https://nabay.gov.lb/send-complaint-ar/,"Official complaint link exists; target 406",manual_review,high,2026-05-30,"Confirm if geoblock/bot issue"
BK011,JOIN_REQUIRED,بلدية البداوي,El-Beddawi,North,Tripoli,https://el-beddawi.gov.lb/send-complaint-ar/,"Official complaint link exists; target 406",manual_review,high,2026-05-30,"Confirm if geoblock/bot issue"
BK012,JOIN_REQUIRED,بلدية النبطية,Nabatieh,Nabatiyeh,Nabatiyeh,"Search deeper within official site for complaint or hotline","Only generic contact found",open,medium,2026-05-30,"Site is live and should be mined deeper"
BK013,JOIN_REQUIRED,بلدية ذوق مكايل,Zouk Mikael,Mount Lebanon,Keserwan,https://zoukmikaelmunicipality.microsoftcrmportals.com/CitizenSignIn,"E-services/app present; complaint use not verified",manual_review,medium,2026-05-30,"May require account"
BK014,JOIN_REQUIRED,بلدية زغرتا-اهدن,Zgharta-Ehden,North,Zgharta,"official Zgharta-Ehden site/contact workflow","No verified official complaint channel found in this pass",open,high,2026-05-30,"Priority city"
BK015,JOIN_REQUIRED,بلدية البترون,Batroun,North,Batroun,"official Batroun site/contact workflow","No working official workflow verified in this pass",open,high,2026-05-30,"Archived official site noted in external references"
BK016,JOIN_REQUIRED,بلدية جزين,Jezzine,South,Jezzine,"official Jezzine site/contact workflow","No verified official complaint channel found in this pass",open,medium,2026-05-30,"Priority district center"
BK017,JOIN_REQUIRED,بلدية الهرمل,Hermel,Baalbek-Hermel,Hermel,"official Hermel site/contact workflow","No verified official complaint channel found in this pass",open,medium,2026-05-30,"Priority district center"
BK018,JOIN_REQUIRED,بلدية راشيا,Rashaya,Bekaa,Rachaya,"official Rashaya site/contact workflow","No verified official complaint channel found in this pass",open,medium,2026-05-30,"Priority district center"
BK019,JOIN_REQUIRED,بلدية جب جنين,Joub Jannine,Bekaa,Western Bekaa,"official Joub Jannine site/contact workflow","No verified official complaint channel found in this pass",open,medium,2026-05-30,"Priority district center"
BK020,JOIN_REQUIRED,بلدية الدبية,Debbiyeh,Mount Lebanon,Chouf,"official Debbiyeh site/contact workflow","No verified official complaint channel found in this pass",open,medium,2026-05-30,"Priority list request"
BK021,JOIN_REQUIRED,بلدية طبرجا-كفرياسين,Tabarja-Kfaryassine,Mount Lebanon,Keserwan,"official Tabarja-Kfaryassine site/contact workflow","No verified official complaint channel found in this pass",open,medium,2026-05-30,"Priority list request"
BK022,JOIN_REQUIRED,بلدية ترشيش,Tarchich,Mount Lebanon,Matn,"official Tarchich site/contact workflow","No verified official complaint channel found in this pass",open,medium,2026-05-30,"Priority list request"
BK023,JOIN_REQUIRED,بلديات اتحاد الفيحاء,Al Fayhaa Union members,North,Tripoli,"Map union fallback to member municipalities in routing layer","Union workflow exists and names members",open,high,2026-05-30,"Important for Tripoli/Mina/Qalamoun/Beddawi fallback"
BK024,JOIN_REQUIRED,اتحادات البلديات,Federations Registry,National,National,https://www.dglac.gov.lb/web/guest/municipal-federations,"DGLAC federations path unreliable in this pass",manual_review,high,2026-05-30,"Needed for broader union mapping"
```

## Open questions and limitations

This pass is intentionally strict. I did **not** treat **Baladi Map** or **Baldati** as official municipal adoption. I also did **not** mark **Nabatieh** or **Zouk Mikael** as having public complaint workflows because only generic contact / app / service evidence was visible. I did **not** infer union memberships beyond the four municipalities explicitly named on the **Al Fayhaa** union site. And I did **not** promote **Jbail-Byblos**, **Jounieh**, **Bcharri**, or **Moukhtara** into trusted official workflows because their present technical states do not justify that. citeturn76view0turn30view1turn61view2turn26view2turn21view3turn24view0turn47view0turn47view1turn61view0

The next best action is straightforward: run a **manual browser review** for the official-but-blocked pages first (**Aley, Nabay, El-Beddawi, Moukhtara, Jounieh, Jbail-Byblos, Bcharri**), then expand the official-only search to the missing priority cities (**Beirut, Saida, Tyre, Baalbek, Zgharta-Ehden, Batroun, Jezzine, Hermel, Rashaya, Joub Jannine, Debbiyeh, Tabarja-Kfaryassine, Tarchich**). That sequence will maximize high-confidence coverage without mixing official evidence with third-party noise.